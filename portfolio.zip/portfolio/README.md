# Full-Stack Personal Portfolio

A professional full-stack portfolio website built to showcase technical skills, projects, and achievements.

## Tech Stack
- **Frontend:** React.js, Vite, Axios, Lucide React
- **Backend:** Node.js, Express.js
- **Database:** MongoDB (Mongoose)

## Features
- **Modern UI:** Responsive, dynamic interface with sleek dark-mode aesthetics.
- **Projects Showcase:** Database-driven project listings with images, tech stacks, and GitHub links.
- **Contact Form:** Database-integrated form for capturing visitor messages.
- **Skill Summary:** Technical skills and educational background sections.

## Getting Started

### 1. Database Setup
Register for a free MongoDB cluster at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and get your connection string.

### 2. Backend Setup
1. Navigate to the `server` directory: `cd server`
2. Install dependencies: `npm install`
3. Edit the `.env` file to replace the default MongoDB URI with your Atlas string:
   ```env
   MONGO_URI=your_mongodb_connection_string
   PORT=5000
   ```
4. Run the seed script to populate default projects: `node seed.js`
5. Start the server: `node index.js`

### 3. Frontend Setup
1. Navigate to the `client` directory: `cd client`
2. Install dependencies: `npm install`
3. Start the Vite dev server: `npm run dev`

Navigate to the provided localhost URL to see your portfolio!
